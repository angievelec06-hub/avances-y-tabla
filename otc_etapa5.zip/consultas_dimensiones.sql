-- =====================================================================
-- OT Consulting - Etapa 5: consultas por tabla de dimensión (SQLite)
-- Cada bloque responde: ¿cuántos valores distintos hay?, ¿cuáles son
-- (si son 10 o menos) o cómo se describen (si son más de 10)? y, en las
-- dimensiones de fecha, ¿cuál es el rango (más antigua / más reciente)?
-- El miembro desconocido (sk = 0) se excluye de todos los conteos.
-- =====================================================================

-- ---------------------------------------------------------------- dim_tiempo
-- [T1] Filas y rango del calendario
SELECT COUNT(*) AS dias, MIN(fecha) AS fecha_mas_antigua, MAX(fecha) AS fecha_mas_reciente,
       COUNT(DISTINCT anio) AS anios
FROM dim_tiempo WHERE sk_tiempo > 0;

-- [T2] Rango de fechas realmente usado por los hechos
SELECT 'hecho_asignacion.inicio' AS origen, MIN(t.fecha) AS mas_antigua, MAX(t.fecha) AS mas_reciente, COUNT(*) AS con_fecha
FROM hecho_asignacion h JOIN dim_tiempo t ON t.sk_tiempo = h.sk_tiempo_inicio WHERE h.sk_tiempo_inicio > 0
UNION ALL
SELECT 'hecho_asignacion.fin', MIN(t.fecha), MAX(t.fecha), COUNT(*)
FROM hecho_asignacion h JOIN dim_tiempo t ON t.sk_tiempo = h.sk_tiempo_fin WHERE h.sk_tiempo_fin > 0
UNION ALL
SELECT 'hecho_activo.resguardo', MIN(t.fecha), MAX(t.fecha), COUNT(*)
FROM hecho_activo h JOIN dim_tiempo t ON t.sk_tiempo = h.sk_tiempo_resguardo WHERE h.sk_tiempo_resguardo > 0;

-- ---------------------------------------------------------------- dim_colaborador
-- [C1] Valores distintos por atributo
SELECT 'colaborador (filas)' AS atributo, COUNT(*) AS distintos FROM dim_colaborador WHERE sk_colaborador > 0
UNION ALL SELECT 'genero', COUNT(DISTINCT genero) FROM dim_colaborador WHERE sk_colaborador > 0
UNION ALL SELECT 'estatus', COUNT(DISTINCT estatus) FROM dim_colaborador WHERE sk_colaborador > 0
UNION ALL SELECT 'ciudad', COUNT(DISTINCT ciudad) FROM dim_colaborador WHERE sk_colaborador > 0
UNION ALL SELECT 'puesto', COUNT(DISTINCT puesto) FROM dim_colaborador WHERE sk_colaborador > 0
UNION ALL SELECT 'departamento', COUNT(DISTINCT departamento) FROM dim_colaborador WHERE sk_colaborador > 0
UNION ALL SELECT 'tipo_nomina', COUNT(DISTINCT tipo_nomina) FROM dim_colaborador WHERE sk_colaborador > 0;

-- [C2] Valores de los atributos con 10 o menos valores
SELECT 'genero' AS atributo, genero AS valor, COUNT(*) AS colaboradores FROM dim_colaborador WHERE sk_colaborador > 0 GROUP BY genero
UNION ALL SELECT 'estatus', estatus, COUNT(*) FROM dim_colaborador WHERE sk_colaborador > 0 GROUP BY estatus
UNION ALL SELECT 'tipo_nomina', COALESCE(tipo_nomina, '(sin dato)'), COUNT(*) FROM dim_colaborador WHERE sk_colaborador > 0 GROUP BY tipo_nomina
UNION ALL SELECT 'departamento', COALESCE(departamento, '(sin dato)'), COUNT(*) FROM dim_colaborador WHERE sk_colaborador > 0 GROUP BY departamento
ORDER BY 1, 3 DESC;

-- [C3] Ciudad (más de 10 valores): top 5 y cola
SELECT COALESCE(ciudad, '(sin dato)') AS ciudad, COUNT(*) AS colaboradores
FROM dim_colaborador WHERE sk_colaborador > 0 GROUP BY ciudad ORDER BY 2 DESC;

-- [C4] Rangos de fecha
SELECT 'fecha_incorporacion' AS campo, MIN(fecha_incorporacion) AS mas_antigua, MAX(fecha_incorporacion) AS mas_reciente, COUNT(fecha_incorporacion) AS con_dato
FROM dim_colaborador WHERE sk_colaborador > 0
UNION ALL SELECT 'fecha_baja', MIN(fecha_baja), MAX(fecha_baja), COUNT(fecha_baja) FROM dim_colaborador WHERE sk_colaborador > 0
UNION ALL SELECT 'fecha_nacimiento', MIN(fecha_nacimiento), MAX(fecha_nacimiento), COUNT(fecha_nacimiento) FROM dim_colaborador WHERE sk_colaborador > 0;

-- ---------------------------------------------------------------- dim_puesto
-- [P1] Valores distintos y descripción (23 puestos: se agrupan por familia)
SELECT COUNT(*) AS puestos FROM dim_puesto WHERE sk_puesto > 0;
SELECT p.puesto, COUNT(c.sk_colaborador) AS colaboradores
FROM dim_puesto p LEFT JOIN dim_colaborador c ON c.puesto = p.puesto AND c.sk_colaborador > 0
WHERE p.sk_puesto > 0 GROUP BY p.puesto ORDER BY colaboradores DESC, p.puesto;
-- [P2] Nivel (último término del nombre) y familia
SELECT CASE WHEN puesto LIKE '%GERENTE%' THEN 'Gerente'
            WHEN puesto LIKE '%SENIOR' THEN 'Senior'
            WHEN puesto LIKE '%ANALISTA' THEN 'Analista'
            ELSE 'Otro' END AS nivel, COUNT(*) AS puestos
FROM dim_puesto WHERE sk_puesto > 0 GROUP BY 1 ORDER BY 2 DESC;

-- ---------------------------------------------------------------- dim_departamento
-- [D1] 6 valores: se listan
SELECT d.codigo, d.nombre, d.estatus, COUNT(c.sk_colaborador) AS colaboradores_con_depto_capturado,
       d.responsable, d.centro_costos
FROM dim_departamento d LEFT JOIN dim_colaborador c ON c.departamento = d.nombre AND c.sk_colaborador > 0
WHERE d.sk_departamento > 0 GROUP BY d.sk_departamento ORDER BY d.codigo;

-- ---------------------------------------------------------------- dim_cliente
-- [CL1] 8 valores: se listan
SELECT codigo_cliente, cliente, industria, estatus, n_proyectos,
       (SELECT COUNT(DISTINCT h.sk_colaborador) FROM hecho_asignacion h WHERE h.sk_cliente = c.sk_cliente) AS colaboradores_asignados
FROM dim_cliente c WHERE sk_cliente > 0 ORDER BY codigo_cliente;
-- [CL2] Industrias distintas
SELECT industria, COUNT(*) AS clientes FROM dim_cliente WHERE sk_cliente > 0 GROUP BY industria ORDER BY 2 DESC;

-- ---------------------------------------------------------------- dim_proyecto
-- [PR1] 12 valores (más de 10): descripción por estatus y cliente
SELECT estatus, COUNT(*) AS proyectos FROM dim_proyecto WHERE sk_proyecto > 0 GROUP BY estatus;
SELECT cliente, COUNT(*) AS proyectos FROM dim_proyecto WHERE sk_proyecto > 0 GROUP BY cliente ORDER BY 2 DESC, 1;
SELECT p.llave_proyecto, p.cliente, p.proyecto, p.estatus, p.fecha_inicio, p.fecha_fin,
       (SELECT COUNT(*) FROM hecho_asignacion h WHERE h.sk_proyecto = p.sk_proyecto) AS asignaciones
FROM dim_proyecto p WHERE sk_proyecto > 0 ORDER BY p.cliente, p.proyecto;
-- [PR2] Rango de fechas
SELECT 'fecha_inicio' AS campo, MIN(fecha_inicio) AS mas_antigua, MAX(fecha_inicio) AS mas_reciente, COUNT(fecha_inicio) AS con_dato FROM dim_proyecto WHERE sk_proyecto > 0
UNION ALL SELECT 'fecha_fin', MIN(fecha_fin), MAX(fecha_fin), COUNT(fecha_fin) FROM dim_proyecto WHERE sk_proyecto > 0;

-- ---------------------------------------------------------------- dim_rol
-- [R1] 1 valor
SELECT r.rol_asignado, COUNT(h.sk_asignacion) AS asignaciones
FROM dim_rol r LEFT JOIN hecho_asignacion h ON h.sk_rol = r.sk_rol WHERE r.sk_rol > 0 GROUP BY r.rol_asignado;
-- [R2] Asignaciones sin rol capturado (miembro desconocido)
SELECT COUNT(*) AS asignaciones_sin_rol FROM hecho_asignacion WHERE sk_rol = 0;

-- ---------------------------------------------------------------- dim_habilidad
-- [H1] 71 valores (más de 10): descripción por tecnología y tipo
SELECT tecnologia, tipo, COUNT(*) AS habilidades FROM dim_habilidad WHERE sk_habilidad > 0 GROUP BY tecnologia, tipo ORDER BY habilidades DESC;
SELECT COUNT(*) AS descripciones_repetidas FROM dim_habilidad WHERE descripcion_repetida = 1 AND sk_habilidad > 0;
-- [H2] Habilidades con más evaluaciones
SELECT h.cod_habilidad, h.descripcion_unica, COUNT(f.sk_habilidad_hecho) AS evaluaciones
FROM dim_habilidad h LEFT JOIN hecho_habilidad f ON f.sk_habilidad = h.sk_habilidad
WHERE h.sk_habilidad > 0 GROUP BY h.sk_habilidad ORDER BY evaluaciones DESC LIMIT 10;

-- ---------------------------------------------------------------- dim_activo
-- [A1] 123 valores (más de 10): descripción por atributo
SELECT 'activos' AS atributo, COUNT(*) AS distintos FROM dim_activo WHERE sk_activo > 0
UNION ALL SELECT 'marca', COUNT(DISTINCT marca) FROM dim_activo WHERE sk_activo > 0
UNION ALL SELECT 'tipo', COUNT(DISTINCT tipo) FROM dim_activo WHERE sk_activo > 0
UNION ALL SELECT 'modelo', COUNT(DISTINCT modelo) FROM dim_activo WHERE sk_activo > 0
UNION ALL SELECT 'serie', COUNT(DISTINCT serie) FROM dim_activo WHERE sk_activo > 0
UNION ALL SELECT 'estatus', COUNT(DISTINCT estatus) FROM dim_activo WHERE sk_activo > 0;
SELECT marca, tipo, COUNT(*) AS activos FROM dim_activo WHERE sk_activo > 0 GROUP BY marca, tipo ORDER BY activos DESC;
-- [A2] Rango de fechas de resguardo (la dimensión no trae fecha de compra: fcompra es nula)
SELECT MIN(t.fecha) AS mas_antigua, MAX(t.fecha) AS mas_reciente, COUNT(*) AS con_fecha
FROM hecho_activo h JOIN dim_tiempo t ON t.sk_tiempo = h.sk_tiempo_resguardo WHERE h.sk_tiempo_resguardo > 0;
