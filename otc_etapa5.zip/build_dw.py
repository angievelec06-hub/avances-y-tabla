#!/usr/bin/env python3
"""
OT Consulting - Etapa 5: acondicionamiento + modelo dimensional fisico (sqlite).

Uso:
    python build_dw.py [--fuente DATASET_BASE_OTC.xlsx] [--db otc_dw.sqlite] [--corte 2026-11-20]

Lee el dataset original (mismas 10 hojas que exporta la PWA de Firebase),
aplica los metodos M1-M11 del Etapa 5, y crea:
  dim_tiempo, dim_colaborador, dim_puesto, dim_departamento, dim_cliente,
  dim_proyecto, dim_rol, dim_habilidad, dim_activo
  hecho_asignacion, hecho_habilidad, hecho_activo
  log_correcciones
Todo se reconstruye desde cero en cada corrida (replicable).
"""
import argparse, re, sqlite3, unicodedata, difflib
import pandas as pd
import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument("--fuente", default="DATASET_BASE_OTC.xlsx")
ap.add_argument("--db", default="otc_dw.sqlite")
ap.add_argument("--corte", default="2026-11-20")
args = ap.parse_args()
CORTE = pd.Timestamp(args.corte)

LOG = []  # (tabla, columna, id, original, corregido, metodo)

# ----------------------------------------------------------------- helpers
SENTINELAS = {"PENDIENTE", "XXXX", "N/A", "NA", "-", "..", "", "INDEFINIDO", "NONE", "NAN"}

def m1(s):
    """M1 normalizacion de texto: trim, espacios repetidos."""
    if pd.isna(s): return np.nan
    return re.sub(r"\s+", " ", str(s)).strip()

def m2(s, tabla="", col="", ident=""):
    """M2 nulificacion de centinelas."""
    s = m1(s)
    if isinstance(s, float): return np.nan
    if s.upper() in SENTINELAS:
        LOG.append((tabla, col, ident, s, None, "M2")); return np.nan
    return s

def sin_acentos(s):
    return "".join(c for c in unicodedata.normalize("NFD", str(s)) if unicodedata.category(c) != "Mn")

def clave_nombre(s):
    s = m1(s)
    if not isinstance(s, str): return ""
    return re.sub(r"[^A-Z ]", "", sin_acentos(s).upper()).strip()

def fecha(s, tabla="", col="", ident=""):
    """M4 + M2: fecha o nulo; 1990-01-01 es relleno."""
    d = pd.to_datetime(m1(s), errors="coerce")
    if pd.notna(d) and d == pd.Timestamp("1990-01-01"):
        LOG.append((tabla, col, ident, "1990-01-01", None, "M2")); return pd.NaT
    return d

def sk_fecha(d):
    return 0 if pd.isna(d) else int(d.strftime("%Y%m%d"))

# ----------------------------------------------------------------- carga
x = pd.read_excel(args.fuente, sheet_name=None, dtype=object)
col_src, asg_src, act_src = x["Colaboradores"], x["Asignaciones_Colaboradores"], x["Inventario_Activos"]
cli_src, dep_src, hab_src = x["Clientes_Proyectos"], x["Departamentos"], x["Habilidades"]
mat_src = x["Matriz Habilidades"]

# ----------------------------------------------------------------- catalogos (M3)
CIUDAD = {  # variantes -> valor canonico
    "MTY": "Monterrey", "MONTERREY": "Monterrey",
    "CDMX": "CDMX", "EDO DE MEXICO": "Estado de México", "TOLUCA": "Toluca",
    "QUERETARO": "Querétaro", "ENSENADA, BAJA CALIFORNIA": "Ensenada", "ENSENADA": "Ensenada",
    "JALISCO": "Jalisco", "GUADALAJARA": "Guadalajara",
    "SALTILLO (VILLAS DE ARANJUEZ)": "Saltillo", "MUGICA, MICHOACAN": "Múgica",
    "TUXTLA GUTIERREZ CHIAPAS": "Tuxtla Gutiérrez", "MATRIZ COPORATIVA": "Matriz Corporativa",
}
def ciudad(s):
    s = m2(s)
    if isinstance(s, float): return s
    return CIUDAD.get(sin_acentos(s).upper(), s.title())

MARCA = {"DELL": "Dell", "HP": "HP", "LENOVO": "Lenovo", "ACER": "Acer", "ASUS": "Asus"}
NOMINA = {  # esquema de nomina homologado
    "SMR": "SMR", "OTC-SINDICATO (SMR)": "SMR", "MODALIDAD 40-SMR": "SMR",
    "MAGNESON-SINDICATO": "Sindicato Magneson", "XERES OT-SINDICATO": "Sindicato Xeres",
    "OTC 100%": "OTC 100%", "ADMINISTRATIVA": "Administrativa",
    "IRAZU/ASIMILADOS": "Asimilados", "EXTRANJERO": "Extranjero",
}

# ================================================================= DIMENSIONES
# ---- dim_tiempo
dias = pd.date_range("2003-01-01", "2028-12-31", freq="D")
MESES = ["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"]
DIAS = ["lunes","martes","miércoles","jueves","viernes","sábado","domingo"]
dim_tiempo = pd.DataFrame({
    "sk_tiempo": dias.strftime("%Y%m%d").astype(int), "fecha": dias.strftime("%Y-%m-%d"),
    "anio": dias.year, "trimestre": dias.quarter, "mes": dias.month,
    "nombre_mes": [MESES[m-1] for m in dias.month], "semana_iso": dias.isocalendar().week.astype(int).values,
    "dia_semana": [DIAS[d] for d in dias.weekday], "es_fin_semana": (dias.weekday >= 5).astype(int),
    "anio_mes": dias.strftime("%Y%m")})
dim_tiempo = pd.concat([pd.DataFrame([{"sk_tiempo": 0, "fecha": None, "anio": None, "trimestre": None, "mes": None,
    "nombre_mes": "Desconocido", "semana_iso": None, "dia_semana": "Desconocido", "es_fin_semana": None, "anio_mes": None}]),
    dim_tiempo], ignore_index=True)

# ---- dim_departamento (M1, llave por codigo)
d = dep_src.copy()
d["nombre"] = d["nombre"].map(m1)
dim_departamento = pd.DataFrame({
    "codigo": d["codigo"].map(m1), "nombre": d["nombre"], "objetivo": d["objetivo"].map(m1),
    "responsable": d["responsable"].map(m2), "centro_costos": d["centroCostos"].map(m2), "estatus": d["estatus"].map(m1)})
dim_departamento.insert(0, "sk_departamento", range(1, len(dim_departamento) + 1))
DEP_POR_NOMBRE = dict(zip(dim_departamento["nombre"].str.upper(), dim_departamento["sk_departamento"]))

# ---- dim_colaborador (M1-M4, M7, M8, M11)
c = col_src.copy()
rows = []
doc_cols = [k for k in c.columns if k.startswith("Doc:")]
DOC_OBLIG = ["Doc: Acta","Doc: INE","Doc: CURP","Doc: Const. Situación Fiscal","Doc: NSS",
             "Doc: Comprobante Domicilio","Doc: Banco","Doc: Foto","Doc: Contrato"]
for _, r in c.iterrows():
    i = m1(r["ID"])
    puesto = m2(r["Puesto"], "colaborador", "puesto", i)
    dep = m2(r["Departamento"], "colaborador", "departamento", i)
    f_inc = fecha(r["Fecha Incorporación"], "colaborador", "fecha_incorporacion", i)
    f_baja = fecha(r["Fecha de Baja"], "colaborador", "fecha_baja", i)
    f_nac = fecha(r["Fecha Nacimiento"], "colaborador", "fecha_nacimiento", i)
    estatus = m1(r["Estatus"])
    incons = 0
    if estatus == "Activo" and pd.notna(f_baja):          # M8: activo con baja
        LOG.append(("colaborador", "fecha_baja", i, str(f_baja.date()), None, "M8")); f_baja = pd.NaT; incons = 1
    if pd.notna(f_baja) and pd.notna(f_inc) and f_baja < f_inc:
        LOG.append(("colaborador", "fecha_baja", i, str(f_baja.date()), None, "M8")); f_baja = pd.NaT; incons = 1
    sueldo_n = pd.to_numeric(r["Sueldo Neto Total"], errors="coerce")
    sueldo_i = pd.to_numeric(r["Sueldo Total Integrado"], errors="coerce")
    for nom, v in (("sueldo_neto_total", sueldo_n), ("sueldo_total_integrado", sueldo_i)):
        if v == 0: LOG.append(("colaborador", nom, i, "0", None, "M11"))
    sueldo_n = np.nan if sueldo_n == 0 else sueldo_n
    sueldo_i = np.nan if sueldo_i == 0 else sueldo_i
    fin = f_baja if pd.notna(f_baja) else CORTE
    ant = None if pd.isna(f_inc) else max(0, (fin.year - f_inc.year) * 12 + fin.month - f_inc.month - (1 if fin.day < f_inc.day else 0))
    def doc_ok(k):
        v = str(m1(r[k])).upper()
        return v in ("PLANTA", "POR PROYECTO") if k == "Doc: Contrato" else v in ("SI", "NA", "NO APLICA")
    docs_ok = sum(doc_ok(k) for k in DOC_OBLIG)
    nom_raw = m2(r["Tipo Nómina"], "colaborador", "tipo_nomina", i)
    rows.append(dict(
        id_colaborador=i, nombre_completo=m1(r["Nombre Completo"]).title(), genero=m1(r["Género"]),
        ciudad=ciudad(r["Ciudad"]), estatus=estatus, puesto=puesto, departamento=dep,
        fecha_incorporacion=f_inc, fecha_baja=f_baja, fecha_nacimiento=f_nac,
        tipo_nomina=NOMINA.get(nom_raw, nom_raw) if isinstance(nom_raw, str) else None,
        sueldo_neto_total=sueldo_n, sueldo_total_integrado=sueldo_i,
        costo_mensual=sueldo_i, costo_hora=None if pd.isna(sueldo_i) else round(sueldo_i / 160, 2),
        es_plantilla=0 if (isinstance(puesto, str) and puesto.upper() == "FAMILIAR COLABORADOR") else 1,
        antiguedad_meses=ant,
        edad=None if pd.isna(f_nac) else int((CORTE - f_nac).days / 365.25),
        baja_primer_anio=int(estatus == "Baja" and ant is not None and ant < 12),
        pct_expediente=round(100 * docs_ok / len(DOC_OBLIG), 1),
        expediente_completo=int(docs_ok == len(DOC_OBLIG)),
        tiene_contrato=int(str(m1(r["Doc: Contrato"])).upper() in ("PLANTA", "POR PROYECTO")),
        falta_puesto=int(puesto is None or isinstance(puesto, float)), falta_departamento=int(dep is None or isinstance(dep, float)),
        falta_nomina=int(isinstance(nom_raw, float)), falta_fecha_baja=int(estatus == "Baja" and pd.isna(f_baja)),
        falta_sueldo=int(pd.isna(sueldo_i)), inconsistencia_estatus=incons))
dim_colaborador = pd.DataFrame(rows)
for k in ("puesto", "departamento"):
    dim_colaborador[k] = dim_colaborador[k].where(dim_colaborador[k].notna(), None)
dim_colaborador["falta_ciudad"] = dim_colaborador["ciudad"].isna().astype(int)
dim_colaborador["falta_departamento"] = dim_colaborador["departamento"].isna().astype(int)

# ---- dim_puesto
puestos = sorted(dim_colaborador["puesto"].dropna().unique())
dim_puesto = pd.DataFrame({"sk_puesto": range(1, len(puestos) + 1), "id_puesto": range(1, len(puestos) + 1), "puesto": puestos})
PUESTO_SK = dict(zip(dim_puesto["puesto"], dim_puesto["sk_puesto"]))

# ---- dim_cliente / dim_proyecto (M5: id_proyecto generado)
cp = cli_src.copy()
for k in cp.columns: cp[k] = cp[k].map(m2)
cp["Cliente"] = cp["Cliente"].map(lambda s: m1(s).replace("Mèxico", "México"))
clientes = cp.drop_duplicates("Cód Cliente")
dim_cliente = pd.DataFrame({
    "sk_cliente": range(1, len(clientes) + 1), "id_cliente": clientes["Cód Cliente"].str[1:].astype(int).values,
    "codigo_cliente": clientes["Cód Cliente"].values, "cliente": clientes["Cliente"].values,
    "industria": clientes["Industria"].values, "ciudad": None, "estado": None, "pais": None,
    "contacto_nom": clientes["Contacto Principal"].values, "estatus": clientes["Estatus Cliente"].values})
dim_cliente["n_proyectos"] = dim_cliente["codigo_cliente"].map(cp.groupby("Cód Cliente")["Proyecto"].nunique()).astype("Int64")
CLI_SK = dict(zip(dim_cliente["codigo_cliente"], dim_cliente["sk_cliente"]))
CLI_NOM = dict(zip(dim_cliente["cliente"].map(clave_nombre), dim_cliente["codigo_cliente"]))

cp["llave"] = cp["Cliente"].map(clave_nombre) + "|" + cp["Proyecto"].map(clave_nombre)
dim_proyecto = pd.DataFrame({
    "sk_proyecto": range(1, len(cp) + 1), "id_proyecto": range(1, len(cp) + 1),
    "llave_proyecto": ["P%04d" % n for n in range(1, len(cp) + 1)], "proyecto": cp["Proyecto"].values,
    "cliente": cp["Cliente"].values,
    "fecha_inicio": [fecha(v, "proyecto", "fecha_inicio", k) for v, k in zip(cp["Fecha Inicio"], cp["llave"])],
    "fecha_fin": [fecha(v, "proyecto", "fecha_fin", k) for v, k in zip(cp["Fecha Fin"], cp["llave"])],
    "estatus": cp["Estatus Proyecto"].values, "resp_cli": cp["PM Cliente"].values,
    "pm_otc": cp["PM OTC"].map(lambda s: s if isinstance(s, float) else s.title()).values})
PROY_SK = dict(zip(cp["llave"], dim_proyecto["sk_proyecto"]))
PROY_CLI = dict(zip(cp["llave"], cp["Cód Cliente"]))

# ---- dim_rol
roles = sorted({m2(v) for v in asg_src["Rol Asignado"]} - {np.nan})
roles = [r for r in roles if isinstance(r, str)]
dim_rol = pd.DataFrame({"sk_rol": range(1, len(roles) + 1), "rol_asignado": roles})
ROL_SK = dict(zip(dim_rol["rol_asignado"], dim_rol["sk_rol"]))

# ---- dim_habilidad (M6: descripcion unica por tecnologia)
h = hab_src.copy()
dim_habilidad = pd.DataFrame({"cod_habilidad": h["codigo"].map(m1).str.upper(), "descripcion": h["descripcion"].map(m1),
    "tecnologia": h["tecnologia"].map(m1), "tipo": h["tipo"].map(m1).map({"HARD": "Dura", "SOFT": "Blanda"}), "estatus": h["estatus"].map(m1)})
dim_habilidad["descripcion_unica"] = dim_habilidad["tecnologia"] + " - " + dim_habilidad["descripcion"]
dim_habilidad["descripcion_repetida"] = dim_habilidad.duplicated("descripcion", keep=False).astype(int)
dim_habilidad.insert(0, "sk_habilidad", range(1, len(dim_habilidad) + 1))
HAB_SK = dict(zip(dim_habilidad["cod_habilidad"], dim_habilidad["sk_habilidad"]))

# ---- dim_activo (M1, M3 marca, M11 costo)
a = act_src.copy()
dim_activo = pd.DataFrame({
    "codigo": a["Cód Activo"].map(m1).str.upper(), "desc": a["Descripción"].map(m1), "tipo": a["Tipo"].map(m1),
    "marca": a["Marca"].map(lambda s: MARCA.get(m1(s).upper(), m1(s).title())),
    "modelo": a["Modelo"].map(m1), "serie": a["Serie"].map(lambda s: m2(s, "activo", "serie")),
    "proveedor": None, "fcompra": None, "estatus": a["Estatus"].map(m1), "notas": None})
for orig, new in zip(a["Marca"], dim_activo["marca"]):
    if m1(orig) != new: LOG.append(("activo", "marca", "", orig, new, "M3"))
dim_activo.insert(0, "sk_activo", range(1, len(dim_activo) + 1))
ACT_SK = dict(zip(dim_activo["codigo"], dim_activo["sk_activo"]))

# ---- miembro desconocido (sk = 0) en cada dimension
def con_desconocido(df, **vals):
    fila = {k: None for k in df.columns}; fila.update(vals)
    return pd.concat([pd.DataFrame([fila]), df], ignore_index=True)

dim_colaborador.insert(0, "sk_colaborador", range(1, len(dim_colaborador) + 1))
COL_SK = dict(zip(dim_colaborador["id_colaborador"], dim_colaborador["sk_colaborador"]))
COL_KEY = {clave_nombre(n): i for i, n in zip(dim_colaborador["id_colaborador"], dim_colaborador["nombre_completo"])}
COL_BY_ID = dim_colaborador.set_index("id_colaborador")

# versionado SCD2 (una version vigente por colaborador; el historial crece en corridas futuras)
dim_colaborador["version_scd"] = 1
dim_colaborador["vigente_desde"] = dim_colaborador["fecha_incorporacion"]
dim_colaborador["vigente_hasta"] = pd.NaT
dim_colaborador["es_actual"] = 1
dim_proyecto["version_scd"] = 1; dim_proyecto["vigente_desde"] = dim_proyecto["fecha_inicio"]
dim_proyecto["vigente_hasta"] = pd.NaT; dim_proyecto["es_actual"] = 1

# ================================================================= HECHOS
# ---- hecho_asignacion (M5, M8, M9, M10)
asg = asg_src.copy()
filas, cierres = [], 0
for n, (_, r) in enumerate(asg.iterrows(), 1):
    i = m1(r["ID Colaborador"])
    llave = clave_nombre(r["Cliente"]) + "|" + clave_nombre(r["Proyecto"])
    f_ini = fecha(r["Fecha Inicio"], "asignacion", "fecha_inicio", f"A{n:03d}")
    f_fin = fecha(r["Fecha Fin"], "asignacion", "fecha_fin", f"A{n:03d}")
    cb = COL_BY_ID.loc[i]
    if pd.notna(cb["fecha_baja"]) and (pd.isna(f_fin) or f_fin > cb["fecha_baja"]):   # M10
        f_fin = cb["fecha_baja"]; cierres += 1
    rol = m2(r["Rol Asignado"], "asignacion", "rol_asignado", f"A{n:03d}")
    puesto = cb["puesto"]
    dep = cb["departamento"]
    cm = cb["costo_mensual"]; ch = cb["costo_hora"]
    pct = 100.0
    filas.append(dict(
        sk_asignacion=n, id_asignacion=f"A{n:03d}", sk_tiempo_inicio=sk_fecha(f_ini), sk_tiempo_fin=sk_fecha(f_fin),
        sk_colaborador=COL_SK[i], sk_puesto=PUESTO_SK.get(puesto, 0) if isinstance(puesto, str) else 0,
        sk_departamento=DEP_POR_NOMBRE.get(str(dep).strip().upper(), 0) if isinstance(dep, str) else 0,
        sk_cliente=CLI_SK[PROY_CLI[llave]], sk_proyecto=PROY_SK[llave],
        sk_rol=ROL_SK.get(rol, 0) if isinstance(rol, str) else 0,
        tipo_de_asignacion=m1(r["Tipo de Asignación"]), pct_dedicacion=pct, pct_dedicacion_supuesto=1,
        costo_mensual_asignado=None if pd.isna(cm) else round(cm * pct / 100, 2),
        costo_hora_asignado=None if pd.isna(ch) else round(ch * pct / 100, 4),
        dias_asignados=None if pd.isna(f_ini) else int(((f_fin if pd.notna(f_fin) else CORTE) - f_ini).days),
        dias_para_fin=None if pd.isna(f_fin) else int((f_fin - CORTE).days),
        es_vigente=int(m1(r["Estatus Asignación"]) == "En Curso" and (pd.isna(f_fin) or f_fin >= CORTE)),
        ingreso_facturable=None, margen=None))
hecho_asignacion = pd.DataFrame(filas)

# banderas derivadas por colaborador (dedicacion, banca)
ded = hecho_asignacion[hecho_asignacion.es_vigente == 1].groupby("sk_colaborador")["pct_dedicacion"].sum()
dim_colaborador["dedicacion_total_pct"] = dim_colaborador["sk_colaborador"].map(ded).fillna(0)
dim_colaborador["sobreasignado"] = (dim_colaborador["dedicacion_total_pct"] > 100).astype(int)
dim_colaborador["tiene_asignacion_vigente"] = (dim_colaborador["dedicacion_total_pct"] > 0).astype(int)
ult_fin = {}
for _, r in hecho_asignacion.iterrows():
    f = pd.to_datetime(str(r.sk_tiempo_fin), format="%Y%m%d", errors="coerce") if r.sk_tiempo_fin else pd.NaT
    if pd.notna(f): ult_fin[r.sk_colaborador] = max(ult_fin.get(r.sk_colaborador, f), f)
def banca(r):
    if r.tiene_asignacion_vigente or r.estatus != "Activo" or pd.isna(r.fecha_incorporacion): return None
    base = max(r.fecha_incorporacion, ult_fin.get(r.sk_colaborador, r.fecha_incorporacion))
    return int((CORTE - base).days)
dim_colaborador["dias_en_banca"] = dim_colaborador.apply(banca, axis=1)

# ---- hecho_activo (M5 liga por nombre -> id, M11, M10)
filas, sin_dueno = [], 0
nombres_ids = list(COL_KEY.keys())
for n, (_, r) in enumerate(a.iterrows(), 1):
    cod = m1(r["Cód Activo"]).upper()
    k = clave_nombre(r["Colaborador Asignado"]) if pd.notna(r["Colaborador Asignado"]) else ""
    cid = COL_KEY.get(k)
    if cid is None and k:
        cand = difflib.get_close_matches(k, nombres_ids, n=1, cutoff=0.9)
        cid = COL_KEY[cand[0]] if cand else None
        LOG.append(("activo", "id_colaborador", cod, r["Colaborador Asignado"], cid, "M5 fuzzy"))
    if cid is None: sin_dueno += 1
    f_ini = fecha(r["Fecha Inicio"], "activo", "fecha_ini", cod)
    costo = pd.to_numeric(r["Costo"], errors="coerce")
    if costo == 0: LOG.append(("activo", "costo", cod, "0", None, "M11")); costo = np.nan
    devuelto = m1(r["Fecha Fin"]) not in (None, "Activo") and pd.notna(pd.to_datetime(m1(r["Fecha Fin"]), errors="coerce"))
    baja_resp = cid is not None and COL_BY_ID.loc[cid, "estatus"] == "Baja"
    pend = int(baja_resp and not devuelto)
    filas.append(dict(sk_activo_hecho=n, sk_activo=ACT_SK[cod], sk_colaborador=COL_SK[cid] if cid else 0,
        sk_tiempo_resguardo=sk_fecha(f_ini), costo=None if pd.isna(costo) else float(costo),
        dias_en_resguardo=None if pd.isna(f_ini) else int((CORTE - f_ini).days),
        pendiente_recuperar=pend, costo_pendiente=None if (pd.isna(costo) or not pend) else float(costo)))
hecho_activo = pd.DataFrame(filas)
inv = hecho_activo[hecho_activo.sk_colaborador > 0].groupby("sk_colaborador")["costo"].sum(min_count=1)
dim_colaborador["inversion_equipo_col"] = dim_colaborador["sk_colaborador"].map(inv)

# ---- hecho_habilidad (M12 unpivot, escala 1-4)
NIVEL = {"BÁSICO": 1, "BASICO": 1, "INTERMEDIO": 2, "AVANZADO": 3, "EXPERTO": 4}
m = mat_src.copy()
cols_h = [k for k in m.columns if re.match(r"^[HS]\d{4} - ", k)]
filas = []
for _, r in m.iterrows():
    i = m1(r["ID Colaborador"]) if pd.notna(r["ID Colaborador"]) else None
    for k in cols_h:
        v = m1(r[k])
        if isinstance(v, float) or not v: continue
        cod = k.split(" - ")[0].strip().upper()
        filas.append(dict(sk_colaborador=COL_SK.get(i, 0), sk_habilidad=HAB_SK[cod], sk_tiempo=0,
                          nivel_num=NIVEL[sin_acentos(v).upper() if v.upper() not in NIVEL else v.upper()] if (sin_acentos(v).upper() in NIVEL or v.upper() in NIVEL) else None,
                          nivel_txt=v, brecha_nivel=None, matriz_actualizada=None))
hecho_habilidad = pd.DataFrame(filas)
hecho_habilidad.insert(0, "sk_habilidad_hecho", range(1, len(hecho_habilidad) + 1))

# ---- agregar fila 0 (desconocido) y escribir
dim_colaborador = con_desconocido(dim_colaborador, sk_colaborador=0, id_colaborador="DESCONOCIDO", nombre_completo="Desconocido")
dim_puesto = con_desconocido(dim_puesto, sk_puesto=0, id_puesto=0, puesto="Desconocido")
dim_departamento = con_desconocido(dim_departamento, sk_departamento=0, codigo="D0000", nombre="Desconocido")
dim_cliente = con_desconocido(dim_cliente, sk_cliente=0, id_cliente=0, codigo_cliente="C0000", cliente="Desconocido")
dim_proyecto = con_desconocido(dim_proyecto, sk_proyecto=0, id_proyecto=0, llave_proyecto="P0000", proyecto="Desconocido")
dim_rol = con_desconocido(dim_rol, sk_rol=0, rol_asignado="Desconocido")
dim_habilidad = con_desconocido(dim_habilidad, sk_habilidad=0, cod_habilidad="H0000", descripcion="Desconocido")
dim_activo = con_desconocido(dim_activo, sk_activo=0, codigo="A0000", desc="Desconocido")

def fmt(df):
    df = df.copy()
    for k in df.columns:
        if str(df[k].dtype).startswith("datetime"):
            df[k] = df[k].dt.strftime("%Y-%m-%d")
        elif df[k].dtype == object:
            df[k] = df[k].map(lambda v: None if (v is pd.NaT or (isinstance(v, float) and np.isnan(v)))
                              else (v.strftime("%Y-%m-%d") if isinstance(v, pd.Timestamp) else v))
    return df

import os
if os.path.exists(args.db): os.remove(args.db)
con = sqlite3.connect(args.db)
for nombre, df in [("dim_tiempo", dim_tiempo), ("dim_colaborador", dim_colaborador), ("dim_puesto", dim_puesto),
                   ("dim_departamento", dim_departamento), ("dim_cliente", dim_cliente), ("dim_proyecto", dim_proyecto),
                   ("dim_rol", dim_rol), ("dim_habilidad", dim_habilidad), ("dim_activo", dim_activo),
                   ("hecho_asignacion", hecho_asignacion), ("hecho_habilidad", hecho_habilidad), ("hecho_activo", hecho_activo)]:
    fmt(df).to_sql(nombre, con, index=False)
pd.DataFrame(LOG, columns=["tabla", "columna", "registro", "valor_original", "valor_corregido", "metodo"]).to_sql("log_correcciones", con, index=False)
# expediente en formato largo (M12 aplicado a documentos)
exp = c.melt(id_vars=["ID"], value_vars=[k for k in c.columns if k.startswith(("Doc:", "Aviso:", "Formato:"))],
             var_name="documento", value_name="estado")
exp["ID"] = exp["ID"].map(m1); exp["documento"] = exp["documento"].str.replace(r"^(Doc|Aviso|Formato): ?", "", regex=True)
exp["estado"] = exp["estado"].map(m1); exp["obligatorio"] = exp["documento"].isin([k.replace("Doc: ", "") for k in DOC_OBLIG]).astype(int)
exp.rename(columns={"ID": "id_colaborador"}).to_sql("expediente_largo", con, index=False)
pd.DataFrame({"parametro": ["fecha_corte"], "valor": [args.corte]}).to_sql("parametros", con, index=False)
con.executescript(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "vistas_indicadores.sql"), encoding="utf-8").read())
con.commit()

print(f"Base creada: {args.db}  (corte {args.corte})")
for t in ["dim_tiempo","dim_colaborador","dim_puesto","dim_departamento","dim_cliente","dim_proyecto","dim_rol","dim_habilidad","dim_activo",
          "hecho_asignacion","hecho_habilidad","hecho_activo","log_correcciones"]:
    print(f"  {t:20s}", con.execute(f"select count(*) from {t}").fetchone()[0])
print("asignaciones cerradas por baja:", cierres, "| activos sin dueño identificado:", sin_dueno)
con.close()
