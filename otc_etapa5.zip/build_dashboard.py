#!/usr/bin/env python3
"""
Genera el tablero de RH (HTML autocontenido) leyendo las vistas v_* de otc_dw.sqlite.
Uso: python build_dashboard.py [--db otc_dw.sqlite] [--out tablero_otc.html]
Para actualizarlo: correr build_dw.py con la exportacion nueva y luego este script.
"""
import argparse, json, sqlite3

ap = argparse.ArgumentParser()
ap.add_argument("--db", default="otc_dw.sqlite")
ap.add_argument("--out", default="tablero_otc.html")
ap.add_argument("--fragmento", default="", help="ruta opcional: escribe solo el contenido (sin <html>) para publicarlo como artefacto")
args = ap.parse_args()

con = sqlite3.connect(args.db)
con.row_factory = sqlite3.Row
rows = lambda sql: [dict(r) for r in con.execute(sql).fetchall()]
one = lambda sql: dict(con.execute(sql).fetchone())

D = {
    "corte": con.execute("select valor from parametros where parametro='fecha_corte'").fetchone()[0],
    "kpi": one("""select
        (select count(*) from v_plantilla where estatus='Activo') plantilla_activa,
        (select count(*) from v_plantilla where estatus='Baja') bajas,
        (select count(*) from v_plantilla where estatus='Baja' and fecha_baja is not null) bajas_con_fecha,
        (select count(*) from v_banca) banca,
        (select round(sum(costo_mensual),2) from v_banca) banca_costo,
        (select count(*) from v_banca where costo_mensual is null) banca_sin_sueldo,
        (select count(*) from v_sobreasignados) sobreasignados,
        (select round(sum(costo_mensual),2) from v_plantilla where estatus='Activo') costo_nomina,
        (select count(*) from v_plantilla where estatus='Activo' and costo_mensual is null) activos_sin_sueldo"""),
    "rot_mensual": rows("select * from v_rotacion_mensual"),
    "rot_esquema": rows("select valor, plantilla, bajas, pct_bajas from v_rotacion_por_dimension where dimension='esquema_nomina' order by pct_bajas desc, plantilla desc"),
    "permanencia": rows("select * from v_permanencia"),
    "fin": rows("select * from v_fin_asignaciones"),
    "dependencia": rows("select * from v_dependencia_cliente"),
    "sobre": rows("select * from v_sobreasignados"),
    "costo_proyecto": rows("select * from v_costo_proyecto"),
    "nomina": rows("select * from v_costo_nomina_esquema"),
    "hab_riesgo": rows("select descripcion_unica, tecnologia, evaluados, expertos from v_habilidad_expertos where riesgo_persona_clave=1 order by expertos, evaluados desc"),
    "hab_total": con.execute("select count(*) from v_habilidad_expertos").fetchone()[0],
    "cumpl": one("select * from v_cumplimiento"),
    "docs": rows("select * from v_docs_faltantes"),
    "activos": one("select * from v_activos"),
    "sin_equipo": con.execute("select activos_sin_equipo from v_colaboradores_sin_equipo").fetchone()[0],
    "calidad": rows("select * from v_calidad"),
}

CSS = """
:root{--bg:#f3f5f7;--surface:#ffffff;--ink:#14202b;--muted:#566677;--line:#dbe2e9;--accent:#1d5f8c;--accent-soft:#d6e6f2;--warn:#a8480f;--crit:#a82320;--good:#2b7a4b;--track:#e8edf2;
--f-text:'IBM Plex Sans',system-ui,-apple-system,'Segoe UI',sans-serif;--f-num:'IBM Plex Mono',ui-monospace,'SF Mono',Menlo,monospace}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#0e161e;--surface:#16212b;--ink:#e5ecf2;--muted:#9bacbc;--line:#26343f;--accent:#5eaee6;--accent-soft:#1e3a50;--warn:#e8934f;--crit:#f2827b;--good:#62c48b;--track:#223140;color-scheme:dark}}
:root[data-theme="dark"]{--bg:#0e161e;--surface:#16212b;--ink:#e5ecf2;--muted:#9bacbc;--line:#26343f;--accent:#5eaee6;--accent-soft:#1e3a50;--warn:#e8934f;--crit:#f2827b;--good:#62c48b;--track:#223140;color-scheme:dark}
body{background:var(--bg);color:var(--ink);font-family:var(--f-text);font-size:14px;line-height:1.5;margin:0;padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px));padding-block:24px 48px}
.wrap{max-width:1120px;margin:0 auto;display:flex;flex-direction:column;gap:28px}
h1{font-size:26px;line-height:1.2;margin:0;font-weight:600;text-wrap:balance}
h2{font-size:16px;margin:0 0 4px;font-weight:600}
.sub{color:var(--muted);margin:2px 0 0;max-width:70ch}
.head{display:flex;flex-wrap:wrap;gap:8px 24px;justify-content:space-between;align-items:flex-end}
.stamp{font-family:var(--f-num);font-size:12px;color:var(--muted)}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px}
.kpi{background:var(--surface);border:1px solid var(--line);border-radius:6px;padding:14px 16px;min-width:0}
.kpi .l{font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.06em}
.kpi .v{font-family:var(--f-num);font-size:26px;font-weight:500;margin-top:2px;font-variant-numeric:tabular-nums}
.kpi .n{font-size:12px;color:var(--muted);margin-top:2px}
.kpi.alert .v{color:var(--warn)}
.sec{display:flex;flex-direction:column;gap:12px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,420px),1fr));gap:16px}
.card{background:var(--surface);border:1px solid var(--line);border-radius:6px;padding:16px;min-width:0;display:flex;flex-direction:column;gap:10px}
.card h3{font-size:13px;margin:0;font-weight:600}
.card p.note{margin:0;color:var(--muted);font-size:12px}
.row{display:grid;grid-template-columns:minmax(90px,38%) 1fr auto;gap:10px;align-items:center;min-width:0}
.row .name{overflow-wrap:anywhere;font-size:13px}
.track{height:10px;background:var(--track);border-radius:0 3px 3px 0;overflow:hidden}
.bar{height:100%;background:var(--accent);border-radius:0 3px 3px 0}
.bar.warn{background:var(--warn)}
.row .val{font-family:var(--f-num);font-size:12.5px;font-variant-numeric:tabular-nums;text-align:right;min-width:3.5em}
.cols{display:flex;align-items:flex-end;gap:6px;height:150px;padding-top:18px}
.col{flex:1;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;height:100%;min-width:0}
.col .cb{width:100%;max-width:34px;background:var(--accent);border-radius:3px 3px 0 0;min-height:2px}
.col .cv{font-family:var(--f-num);font-size:11px;margin-bottom:3px;color:var(--ink)}
.col .cm{font-family:var(--f-num);font-size:10.5px;color:var(--muted);margin-top:4px}
.tw{overflow-x:auto}
table{border-collapse:collapse;width:100%;font-size:13px}
th{font-size:11.5px;text-transform:uppercase;letter-spacing:.05em;color:var(--muted);text-align:left;font-weight:500;padding:6px 8px;border-bottom:1px solid var(--line)}
td{padding:6px 8px;border-bottom:1px solid var(--line);vertical-align:top}
td.r,th.r{text-align:right;font-family:var(--f-num);font-variant-numeric:tabular-nums}
.tag{display:inline-block;font-size:11px;padding:1px 7px;border-radius:10px;border:1px solid var(--line);color:var(--muted);white-space:nowrap}
.tag.warn{color:var(--warn);border-color:var(--warn)}
.tag.crit{color:var(--crit);border-color:var(--crit)}
.tag.good{color:var(--good);border-color:var(--good)}
.pend li{margin:3px 0}
footer{color:var(--muted);font-size:12px;max-width:80ch}
@media(max-width:520px){.row{grid-template-columns:1fr auto}.row .track{grid-column:1 / -1;order:3}}
"""

JS = r"""
const D = __DATA__;
const $ = s => document.querySelector(s);
const n0 = v => v == null ? '–' : Number(v).toLocaleString('es-MX', {maximumFractionDigits: 0});
const mx = v => v == null ? '–' : Number(v).toLocaleString('es-MX', {style: 'currency', currency: 'MXN', maximumFractionDigits: 0});
const pc = v => v == null ? '–' : Number(v).toLocaleString('es-MX', {maximumFractionDigits: 1}) + '%';
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const MES = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];

function bars(el, items, fmt, cls) {
  const max = Math.max(1, ...items.map(i => i.v || 0));
  $(el).innerHTML = items.map(i => `<div class="row" title="${esc(i.l)}: ${fmt(i.v)}"><div class="name">${esc(i.l)}</div><div class="track"><div class="bar ${cls||''}" style="width:${(i.v||0)/max*100}%"></div></div><div class="val">${fmt(i.v)}</div></div>`).join('');
}
function table(el, head, rowsHtml) {
  $(el).innerHTML = `<div class="tw"><table><thead><tr>${head.map(h => `<th class="${h.r?'r':''}">${esc(h.t)}</th>`).join('')}</tr></thead><tbody>${rowsHtml}</tbody></table></div>`;
}
const k = D.kpi;
$('#corte').textContent = 'Corte ' + D.corte;
$('#kpis').innerHTML = [
  ['Plantilla activa', n0(k.plantilla_activa), 'sin familiares de seguro'],
  ['Bajas registradas', n0(k.bajas), n0(k.bajas_con_fecha) + ' con fecha capturada', 'alert'],
  ['En banca', n0(k.banca), 'activos sin asignación vigente', 'alert'],
  ['Costo mensual de banca', mx(k.banca_costo), n0(k.banca_sin_sueldo) + ' sin sueldo capturado'],
  ['Sobreasignados', n0(k.sobreasignados), 'dedicación mayor a 100%', k.sobreasignados ? 'alert' : ''],
  ['Nómina mensual activa', mx(k.costo_nomina), n0(k.activos_sin_sueldo) + ' activos sin sueldo capturado'],
  ['Equipo no recuperado', mx(D.activos.valor_no_recuperado), n0(D.activos.pendientes_recuperar) + ' equipos de personal dado de baja', 'alert'],
].map(x => `<div class="kpi ${x[3]||''}"><div class="l">${x[0]}</div><div class="v">${x[1]}</div><div class="n">${x[2]}</div></div>`).join('');

// Rotación
const rm = D.rot_mensual;
const rmax = Math.max(1, ...rm.map(r => r.bajas));
$('#rot-mes').innerHTML = rm.map(r => {
  const pct = (r.activos_inicio + r.activos_cierre) ? r.bajas / ((r.activos_inicio + r.activos_cierre) / 2) * 100 : 0;
  return `<div class="col" title="${r.anio_mes}: ${r.bajas} bajas, rotación ${pct.toFixed(1)}%"><div class="cv">${r.bajas}</div><div class="cb" style="height:${r.bajas/rmax*100}%"></div><div class="cm">${MES[+r.anio_mes.slice(4)-1]}</div></div>`;
}).join('');
const anual = rm.reduce((a, r) => a + r.bajas, 0);
const prom = rm.reduce((a, r) => a + (r.activos_inicio + r.activos_cierre) / 2, 0) / rm.length;
$('#rot-anual').textContent = `Rotación acumulada 2026: ${anual} bajas con fecha sobre una plantilla promedio de ${prom.toFixed(0)} personas, ${(anual/prom*100).toFixed(1)}%. Está subestimada: ${k.bajas - k.bajas_con_fecha} bajas no tienen fecha.`;
table('#rot-esq', [{t:'Esquema'},{t:'Plantilla',r:1},{t:'Bajas',r:1},{t:'% bajas',r:1}],
  D.rot_esquema.map(r => `<tr><td>${esc(r.valor)}</td><td class="r">${r.plantilla}</td><td class="r">${r.bajas}</td><td class="r">${pc(r.pct_bajas)}</td></tr>`).join(''));
table('#perm', [{t:'Año de ingreso'},{t:'Bajas con fecha',r:1},{t:'Permanencia (meses)',r:1}],
  D.permanencia.map(r => `<tr><td>${r.anio_ingreso}</td><td class="r">${r.bajas_con_fecha}</td><td class="r">${r.permanencia_meses}</td></tr>`).join(''));

// Asignación
bars('#dep', D.dependencia.map(r => ({l: r.cliente, v: r.pct_plantilla})), pc);
$('#dep-n').textContent = D.dependencia.map(r => `${r.cliente}: ${r.colaboradores}`).join(' · ') + ' consultores asignados.';
table('#fin', [{t:'Consultor'},{t:'Cliente / proyecto'},{t:'Días',r:1},{t:'Ventana'}],
  D.fin.map(r => `<tr><td>${esc(r.nombre_completo)}</td><td>${esc(r.cliente)} / ${esc(r.proyecto)}</td><td class="r">${n0(r.dias_para_fin)}</td><td><span class="tag ${r.bucket==='31-60'||r.bucket==='0-30'?'warn':''}">${r.bucket}</span></td></tr>`).join(''));
table('#sobre', [{t:'Consultor'},{t:'Dedicación',r:1}],
  D.sobre.map(r => `<tr><td>${esc(r.nombre_completo)}</td><td class="r"><span class="tag crit">${r.dedicacion_total_pct}%</span></td></tr>`).join('') || '<tr><td colspan="2">Sin casos</td></tr>');

// Costos
bars('#cproy', D.costo_proyecto.map(r => ({l: r.cliente + ' / ' + r.proyecto, v: r.costo_mensual})), mx);
bars('#cnom', D.nomina.filter(r => r.costo_mensual).map(r => ({l: r.esquema + ' (' + r.con_sueldo + ' de ' + r.colaboradores + ' con sueldo)', v: r.costo_mensual})), mx);

// Habilidades
table('#hab', [{t:'Habilidad'},{t:'Tecnología'},{t:'Evaluados',r:1},{t:'Expertos activos',r:1}],
  D.hab_riesgo.map(r => `<tr><td>${esc(r.descripcion_unica)}</td><td>${esc(r.tecnologia)}</td><td class="r">${r.evaluados}</td><td class="r"><span class="tag ${r.expertos===0?'crit':'warn'}">${r.expertos}</span></td></tr>`).join(''));
$('#hab-n').textContent = `${D.hab_riesgo.length} de ${D.hab_total} habilidades tienen 1 experto o ninguno (nivel avanzado o experto, solo personal activo).`;

// Cumplimiento y activos
bars('#docs', D.docs.map(r => ({l: r.documento, v: r.faltan})), v => n0(v) + ' de ' + n0(D.cumpl.plantilla_activa), 'warn');
$('#cumpl-n').textContent = `${D.cumpl.expediente_completo} de ${D.cumpl.plantilla_activa} activos tienen el expediente completo (${pc(D.cumpl.pct_expediente_completo)}). ${D.cumpl.sin_contrato} no tienen contrato registrado.`;
const a = D.activos;
table('#act', [{t:'Indicador'},{t:'Valor',r:1}], [
  ['Equipos inventariados', n0(a.activos)],
  ['Equipos sin responsable identificado', n0(a.sin_responsable)],
  ['Equipos con costo capturado', n0(a.con_costo) + ' de ' + n0(a.activos)],
  ['Valor de los equipos con costo', mx(a.valor_total)],
  ['Equipos de personal dado de baja', n0(a.pendientes_recuperar)],
  ['Valor no recuperado', mx(a.valor_no_recuperado)],
  ['Activos sin equipo a su nombre', n0(D.sin_equipo)],
].map(r => `<tr><td>${r[0]}</td><td class="r">${r[1]}</td></tr>`).join(''));

// Calidad
bars('#cal', D.calidad.map(r => ({l: r.campo, v: r.filas ? r.faltantes / r.filas * 100 : 0})), pc, 'warn');
"""

BODY = """
<div class="wrap">
  <div class="head">
    <div><h1>Tablero de capital humano OT Consulting</h1>
    <p class="sub">Indicadores calculados sobre el modelo dimensional (sqlite). Un dato desconocido queda vacío y se reporta en calidad de datos; no se rellena.</p></div>
    <div class="stamp" id="corte"></div>
  </div>
  <div class="kpis" id="kpis"></div>

  <section class="sec"><div><h2>Rotación y permanencia</h2><p class="sub">Preguntas 1 a 4 del reto.</p></div>
    <div class="grid">
      <div class="card"><h3>Bajas por mes, 2026</h3><div class="cols" id="rot-mes"></div><p class="note" id="rot-anual"></p></div>
      <div class="card"><h3>Bajas por esquema de nómina</h3><div id="rot-esq"></div><p class="note">Bajas sobre la plantilla total del esquema, con y sin fecha de baja.</p></div>
      <div class="card"><h3>Permanencia de quienes salieron</h3><div id="perm"></div></div>
    </div></section>

  <section class="sec"><div><h2>Asignación y utilización</h2><p class="sub">Preguntas 6, 7, 9 y 10.</p></div>
    <div class="grid">
      <div class="card"><h3>Dependencia por cliente (% de la plantilla activa)</h3><div id="dep"></div><p class="note" id="dep-n"></p></div>
      <div class="card"><h3>Asignaciones con fecha de fin</h3><div id="fin"></div><p class="note">Solo 7 de 31 asignaciones tienen fecha de fin. Ninguna vence en los próximos 30 días.</p></div>
      <div class="card"><h3>Sobreasignación</h3><div id="sobre"></div><p class="note">Se supone 100% de dedicación por asignación porque la fuente no lo captura. Una persona con dos asignaciones suma 200%.</p></div>
    </div></section>

  <section class="sec"><div><h2>Costos</h2><p class="sub">Preguntas 11, 12, 14 y 15. Costo = sueldo total integrado.</p></div>
    <div class="grid">
      <div class="card"><h3>Costo mensual por proyecto</h3><div id="cproy"></div></div>
      <div class="card"><h3>Nómina mensual por esquema (activos)</h3><div id="cnom"></div><p class="note">Los esquemas sin sueldo capturado no aparecen.</p></div>
    </div></section>

  <section class="sec"><div><h2>Habilidades</h2><p class="sub">Preguntas 16 y 20: riesgo de persona clave.</p></div>
    <div class="card"><div id="hab"></div><p class="note" id="hab-n"></p></div></section>

  <section class="sec"><div><h2>Cumplimiento y activos</h2><p class="sub">Preguntas 21 a 25.</p></div>
    <div class="grid">
      <div class="card"><h3>Documentos obligatorios que faltan (plantilla activa)</h3><div id="docs"></div><p class="note" id="cumpl-n"></p></div>
      <div class="card"><h3>Inventario de equipo</h3><div id="act"></div></div>
    </div></section>

  <section class="sec"><div><h2>Calidad de los datos</h2><p class="sub">Porcentaje de valores faltantes en los campos que alimentan los indicadores.</p></div>
    <div class="card"><div id="cal"></div></div></section>

  <section class="sec"><div><h2>Indicadores pendientes de captura</h2></div>
    <div class="card"><ul class="pend">
      <li>Causa de baja y costo de reemplazo (preguntas 3 y 5).</li>
      <li>Horas registradas y tarifa por proyecto: porcentaje facturable y margen (preguntas 8 y 13).</li>
      <li>Certificaciones con vencimiento (pregunta 17).</li>
      <li>Fecha de evaluación de habilidades: matriz actualizada (pregunta 19).</li>
      <li>Nivel requerido por proyecto: consultores en banca con las habilidades que pide un proyecto nuevo (pregunta 18).</li>
    </ul></div></section>

  <footer>Fuente: DATASET_BASE_OTC.xlsx acondicionado con build_dw.py. Regenerar con build_dashboard.py.</footer>
</div>
"""

data = json.dumps(D, ensure_ascii=False, default=str)
js = JS.replace("__DATA__", data)
frag = f"<title>Tablero RH OTC</title>\n<meta name=\"claude:viewport-fit-sides\" content=\"cover\">\n<link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans:wght@400;500;600&display=swap\">\n<style>{CSS}</style>\n{BODY}\n<script>{js}</script>\n"
full = "<!doctype html>\n<html lang=\"es\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n" + frag.replace("\n{BODY}", "") + "</head>\n"
# en el archivo independiente el contenido va dentro de <body>
head_part = f"<title>Tablero RH OTC</title>\n<link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans:wght@400;500;600&display=swap\">\n<style>{CSS}</style>"
full = f"<!doctype html>\n<html lang=\"es\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n{head_part}</head>\n<body>{BODY}<script>{js}</script></body></html>\n"
open(args.out, "w", encoding="utf-8").write(full)
if args.fragmento:
    open(args.fragmento, "w", encoding="utf-8").write(frag)
print("Tablero:", args.out, f"({len(full)//1024} KB)")
