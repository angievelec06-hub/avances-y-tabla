-- =====================================================================
-- Vistas de indicadores (capa de consumo del tablero)
-- Reglas: plantilla = es_plantilla = 1; fecha de corte = tabla parametros.
-- Un dato desconocido queda nulo y se reporta en v_calidad, no se imputa.
-- =====================================================================
DROP VIEW IF EXISTS v_plantilla;
CREATE VIEW v_plantilla AS
SELECT * FROM dim_colaborador WHERE sk_colaborador > 0 AND es_plantilla = 1;

-- P1  Rotación mensual (solo bajas con fecha capturada)
DROP VIEW IF EXISTS v_rotacion_mensual;
CREATE VIEW v_rotacion_mensual AS
WITH meses AS (
  SELECT DISTINCT anio_mes, MIN(fecha) AS ini FROM dim_tiempo
  WHERE fecha BETWEEN '2026-01-01' AND (SELECT valor FROM parametros WHERE parametro='fecha_corte') GROUP BY anio_mes)
SELECT m.anio_mes,
  (SELECT COUNT(*) FROM v_plantilla p WHERE p.fecha_baja >= m.ini AND p.fecha_baja < date(m.ini,'+1 month')) AS bajas,
  (SELECT COUNT(*) FROM v_plantilla p WHERE p.fecha_incorporacion < m.ini AND (p.fecha_baja IS NULL OR p.fecha_baja >= m.ini)) AS activos_inicio,
  (SELECT COUNT(*) FROM v_plantilla p WHERE p.fecha_incorporacion < date(m.ini,'+1 month') AND (p.fecha_baja IS NULL OR p.fecha_baja >= date(m.ini,'+1 month'))) AS activos_cierre
FROM meses m ORDER BY m.anio_mes;

-- P1  Rotación por puesto / departamento / esquema (bajas con fecha y sin fecha, sobre plantilla total)
DROP VIEW IF EXISTS v_rotacion_por_dimension;
CREATE VIEW v_rotacion_por_dimension AS
SELECT 'esquema_nomina' AS dimension, COALESCE(tipo_nomina,'(sin dato)') AS valor, COUNT(*) AS plantilla,
       SUM(estatus='Baja') AS bajas, ROUND(100.0*SUM(estatus='Baja')/COUNT(*),1) AS pct_bajas FROM v_plantilla GROUP BY 2
UNION ALL
SELECT 'departamento', COALESCE(departamento,'(sin dato)'), COUNT(*), SUM(estatus='Baja'), ROUND(100.0*SUM(estatus='Baja')/COUNT(*),1) FROM v_plantilla GROUP BY 2
UNION ALL
SELECT 'puesto', COALESCE(puesto,'(sin dato)'), COUNT(*), SUM(estatus='Baja'), ROUND(100.0*SUM(estatus='Baja')/COUNT(*),1) FROM v_plantilla GROUP BY 2;

-- P2  Permanencia promedio de quienes salieron, por año de ingreso
DROP VIEW IF EXISTS v_permanencia;
CREATE VIEW v_permanencia AS
SELECT substr(fecha_incorporacion,1,4) AS anio_ingreso, COUNT(*) AS bajas_con_fecha,
       ROUND(AVG(antiguedad_meses),1) AS permanencia_meses
FROM v_plantilla WHERE estatus='Baja' AND fecha_baja IS NOT NULL GROUP BY 1 ORDER BY 1;

-- P7 / P14  Banca
DROP VIEW IF EXISTS v_banca;
CREATE VIEW v_banca AS
SELECT sk_colaborador, id_colaborador, nombre_completo, puesto, fecha_incorporacion, dias_en_banca, costo_mensual
FROM v_plantilla WHERE estatus='Activo' AND tiene_asignacion_vigente = 0;

-- P6  Asignaciones por terminar (0-30, 31-60, 61-90 días)
DROP VIEW IF EXISTS v_fin_asignaciones;
CREATE VIEW v_fin_asignaciones AS
SELECT c.id_colaborador, c.nombre_completo, p.cliente, p.proyecto, h.dias_para_fin,
       CASE WHEN h.dias_para_fin BETWEEN 0 AND 30 THEN '0-30' WHEN h.dias_para_fin BETWEEN 31 AND 60 THEN '31-60'
            WHEN h.dias_para_fin BETWEEN 61 AND 90 THEN '61-90' WHEN h.dias_para_fin > 90 THEN '>90' ELSE 'vencida' END AS bucket
FROM hecho_asignacion h JOIN dim_colaborador c USING (sk_colaborador) JOIN dim_proyecto p USING (sk_proyecto)
WHERE h.dias_para_fin IS NOT NULL ORDER BY h.dias_para_fin;

-- P9  Dependencia por cliente (% de la plantilla activa)
DROP VIEW IF EXISTS v_dependencia_cliente;
CREATE VIEW v_dependencia_cliente AS
SELECT c.cliente, COUNT(DISTINCT h.sk_colaborador) AS colaboradores,
       ROUND(100.0*COUNT(DISTINCT h.sk_colaborador)/(SELECT COUNT(*) FROM v_plantilla WHERE estatus='Activo'),1) AS pct_plantilla
FROM hecho_asignacion h JOIN dim_cliente c USING (sk_cliente) WHERE h.es_vigente=1 GROUP BY c.cliente ORDER BY 2 DESC;

-- P10  Sobreasignación
DROP VIEW IF EXISTS v_sobreasignados;
CREATE VIEW v_sobreasignados AS
SELECT id_colaborador, nombre_completo, dedicacion_total_pct FROM v_plantilla WHERE sobreasignado = 1;

-- P11/P12/P15  Costos
DROP VIEW IF EXISTS v_costo_proyecto;
CREATE VIEW v_costo_proyecto AS
SELECT c.cliente, p.proyecto, COUNT(*) AS asignaciones, ROUND(SUM(h.costo_mensual_asignado),2) AS costo_mensual,
       SUM(h.costo_mensual_asignado IS NULL) AS asignaciones_sin_sueldo
FROM hecho_asignacion h JOIN dim_proyecto p USING (sk_proyecto) JOIN dim_cliente c USING (sk_cliente)
WHERE h.es_vigente=1 GROUP BY c.cliente, p.proyecto ORDER BY costo_mensual DESC;

DROP VIEW IF EXISTS v_costo_nomina_esquema;
CREATE VIEW v_costo_nomina_esquema AS
SELECT COALESCE(tipo_nomina,'(sin dato)') AS esquema, COUNT(*) AS colaboradores, SUM(costo_mensual IS NOT NULL) AS con_sueldo,
       ROUND(SUM(costo_mensual),2) AS costo_mensual FROM v_plantilla WHERE estatus='Activo' GROUP BY 1 ORDER BY 4 DESC;

-- P16/P20  Habilidades con pocos expertos (nivel >= 3 = avanzado/experto, solo activos)
DROP VIEW IF EXISTS v_habilidad_expertos;
CREATE VIEW v_habilidad_expertos AS
SELECT h.cod_habilidad, h.descripcion_unica, h.tecnologia,
       COUNT(f.sk_habilidad_hecho) AS evaluados,
       SUM(f.nivel_num >= 3 AND c.estatus='Activo') AS expertos,
       CASE WHEN SUM(f.nivel_num >= 3 AND c.estatus='Activo') <= 1 THEN 1 ELSE 0 END AS riesgo_persona_clave
FROM dim_habilidad h LEFT JOIN hecho_habilidad f ON f.sk_habilidad = h.sk_habilidad
LEFT JOIN dim_colaborador c ON c.sk_colaborador = f.sk_colaborador
WHERE h.sk_habilidad > 0 GROUP BY h.sk_habilidad;

-- P21/P22  Cumplimiento
DROP VIEW IF EXISTS v_cumplimiento;
CREATE VIEW v_cumplimiento AS
SELECT COUNT(*) AS plantilla_activa, SUM(expediente_completo) AS expediente_completo,
       ROUND(100.0*SUM(expediente_completo)/COUNT(*),1) AS pct_expediente_completo,
       SUM(tiene_contrato=0) AS sin_contrato FROM v_plantilla WHERE estatus='Activo';

-- P23/P24/P25  Activos
DROP VIEW IF EXISTS v_activos;
CREATE VIEW v_activos AS
SELECT COUNT(*) AS activos, SUM(sk_colaborador=0) AS sin_responsable, SUM(costo IS NOT NULL) AS con_costo,
       ROUND(SUM(costo),2) AS valor_total, SUM(pendiente_recuperar) AS pendientes_recuperar,
       COALESCE(ROUND(SUM(costo_pendiente),2),0) AS valor_no_recuperado,
       SUM(pendiente_recuperar=1 AND costo IS NULL) AS pendientes_sin_costo
FROM hecho_activo;

DROP VIEW IF EXISTS v_colaboradores_sin_equipo;
CREATE VIEW v_colaboradores_sin_equipo AS
SELECT COUNT(*) AS activos_sin_equipo FROM v_plantilla p
WHERE p.estatus='Activo' AND NOT EXISTS (SELECT 1 FROM hecho_activo a WHERE a.sk_colaborador = p.sk_colaborador);

-- Calidad: completitud de los campos que alimentan los indicadores
DROP VIEW IF EXISTS v_calidad;
CREATE VIEW v_calidad AS
SELECT 'puesto' AS campo, COUNT(*) AS filas, SUM(falta_puesto) AS faltantes FROM v_plantilla
UNION ALL SELECT 'departamento', COUNT(*), SUM(falta_departamento) FROM v_plantilla
UNION ALL SELECT 'esquema de nómina', COUNT(*), SUM(falta_nomina) FROM v_plantilla
UNION ALL SELECT 'sueldo', COUNT(*), SUM(falta_sueldo) FROM v_plantilla
UNION ALL SELECT 'fecha de baja (solo bajas)', SUM(estatus='Baja'), SUM(falta_fecha_baja) FROM v_plantilla
UNION ALL SELECT 'rol de la asignación', COUNT(*), SUM(sk_rol=0) FROM hecho_asignacion
UNION ALL SELECT 'fecha inicio de asignación', COUNT(*), SUM(sk_tiempo_inicio=0) FROM hecho_asignacion
UNION ALL SELECT 'fecha fin de asignación', COUNT(*), SUM(sk_tiempo_fin=0) FROM hecho_asignacion
UNION ALL SELECT 'responsable del activo', COUNT(*), SUM(sk_colaborador=0) FROM hecho_activo
UNION ALL SELECT 'costo del activo', COUNT(*), SUM(costo IS NULL) FROM hecho_activo;

-- P21  Documento obligatorio que más falta (plantilla activa)
DROP VIEW IF EXISTS v_docs_faltantes;
CREATE VIEW v_docs_faltantes AS
SELECT e.documento, SUM(CASE WHEN e.documento='Contrato' THEN e.estado NOT IN ('Planta','Por Proyecto')
                              ELSE e.estado NOT IN ('SI','NA','NO APLICA') END) AS faltan, COUNT(*) AS activos
FROM expediente_largo e JOIN v_plantilla p ON p.id_colaborador = e.id_colaborador
WHERE e.obligatorio = 1 AND p.estatus = 'Activo' GROUP BY e.documento ORDER BY faltan DESC;
